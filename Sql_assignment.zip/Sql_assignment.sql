-- ==========================================
-- TechNova Employee Rewards & Performance Management System
-- ==========================================

-- USER STORY 1 : DATABASE SETUP (DDL)

CREATE DATABASE IF NOT EXISTS TechNovaDB;
USE TechNovaDB;

-- Department Table
CREATE TABLE Department (
    DeptID INT PRIMARY KEY,
    DeptName VARCHAR(50) NOT NULL UNIQUE,
    Location VARCHAR(50) NOT NULL
);

-- Employee Table
CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(100) NOT NULL,
    Gender ENUM('M','F','O'),
    DOB DATE NOT NULL,
    HireDate DATE NOT NULL,
    DeptID INT,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

-- Project Table
CREATE TABLE Project (
    ProjectID INT PRIMARY KEY,
    ProjectName VARCHAR(100) NOT NULL,
    DeptID INT,
    StartDate DATE,
    EndDate DATE,
    FOREIGN KEY (DeptID) REFERENCES Department(DeptID)
);

-- Performance Table
CREATE TABLE Performance (
    EmpID INT,
    ProjectID INT,
    Rating DECIMAL(3,1),
    ReviewDate DATE,
    PRIMARY KEY (EmpID, ProjectID),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID),
    FOREIGN KEY (ProjectID) REFERENCES Project(ProjectID)
);

-- Reward Table
CREATE TABLE Reward (
    EmpID INT,
    RewardMonth DATE,
    RewardAmount DECIMAL(10,2),
    PRIMARY KEY (EmpID, RewardMonth),
    FOREIGN KEY (EmpID) REFERENCES Employee(EmpID)
);

-- Indexes
CREATE INDEX idx_empname
ON Employee(EmpName);

CREATE INDEX idx_emp_deptid
ON Employee(DeptID);

-- ==========================================
-- USER STORY 2 : DML OPERATIONS
-- ==========================================

-- Department Records
INSERT INTO Department VALUES
(101,'IT','Bangalore'),
(102,'HR','Delhi'),
(103,'Finance','Mumbai'),
(104,'Marketing','Pune'),
(105,'Operations','Hyderabad');

-- Employee Records
INSERT INTO Employee VALUES
(1,'Asha','F','1990-07-12','2018-06-10',101),
(2,'Raj','M','1988-04-09','2020-03-22',102),
(3,'Neha','F','1995-01-15','2021-08-05',101),
(4,'Amit','M','1992-09-20','2019-11-12',103),
(5,'Priya','F','1997-05-10','2022-02-18',104);

-- Project Records
INSERT INTO Project VALUES
(201,'ERP System',101,'2024-01-01','2024-12-31'),
(202,'HR Portal',102,'2024-02-01','2024-10-31'),
(203,'Budget Tracker',103,'2024-03-01','2024-09-30'),
(204,'Digital Marketing',104,'2024-01-15','2024-08-31'),
(205,'Inventory Automation',105,'2024-04-01','2024-11-30');

-- Performance Records
INSERT INTO Performance VALUES
(1,201,4.5,'2025-01-10'),
(2,202,4.2,'2025-01-12'),
(3,201,4.8,'2025-01-15'),
(4,203,4.0,'2025-01-20'),
(5,204,4.7,'2025-01-25');

-- Reward Records
INSERT INTO Reward VALUES
(1,'2025-01-01',3000),
(2,'2025-01-01',1500),
(3,'2025-02-01',4000),
(4,'2025-02-01',800),
(5,'2025-03-01',2500);

-- Update employee department
UPDATE Employee
SET DeptID = 105
WHERE EmpID = 2;

-- Delete reward less than 1000
DELETE FROM Reward
WHERE RewardAmount < 1000;

-- ==========================================
-- USER STORY 3 : DQL & AGGREGATE FUNCTIONS
-- ==========================================

-- 1. Employees joined after 2019-01-01
SELECT *
FROM Employee
WHERE HireDate > '2019-01-01';

-- 2. Average rating by department
SELECT
    d.DeptName,
    AVG(p.Rating) AS AvgRating
FROM Department d
JOIN Employee e ON d.DeptID = e.DeptID
JOIN Performance p ON e.EmpID = p.EmpID
GROUP BY d.DeptName;

-- 3. Employee age
SELECT
    EmpName,
    TIMESTAMPDIFF(YEAR, DOB, CURDATE()) AS Age
FROM Employee;

-- 4. Total rewards in current year
SELECT
    SUM(RewardAmount) AS TotalRewards
FROM Reward
WHERE YEAR(RewardMonth) = YEAR(CURDATE());

-- 5. Employees with rewards > 2000
SELECT
    e.EmpID,
    e.EmpName,
    r.RewardAmount
FROM Employee e
JOIN Reward r
ON e.EmpID = r.EmpID
WHERE r.RewardAmount > 2000;

-- ==========================================
-- USER STORY 4 : JOINS & SUBQUERIES
-- ==========================================

-- 1. Employee, Department, Project, Rating
SELECT
    e.EmpName,
    d.DeptName,
    pr.ProjectName,
    p.Rating
FROM Employee e
JOIN Department d
ON e.DeptID = d.DeptID
JOIN Performance p
ON e.EmpID = p.EmpID
JOIN Project pr
ON p.ProjectID = pr.ProjectID;

-- 2. Highest rated employee in each department
SELECT
    d.DeptName,
    e.EmpName,
    p.Rating
FROM Employee e
JOIN Department d
ON e.DeptID = d.DeptID
JOIN Performance p
ON e.EmpID = p.EmpID
WHERE p.Rating =
(
    SELECT MAX(p2.Rating)
    FROM Employee e2
    JOIN Performance p2
    ON e2.EmpID = p2.EmpID
    WHERE e2.DeptID = e.DeptID
);

-- 3. Employees without rewards
SELECT *
FROM Employee
WHERE EmpID NOT IN
(
    SELECT EmpID
    FROM Reward
);

-- ==========================================
-- USER STORY 5 : TCL (TRANSACTION CONTROL)
-- ==========================================

START TRANSACTION;

INSERT INTO Employee
VALUES
(6,'Rohan','M','1998-10-15','2025-01-01',101);

INSERT INTO Performance
VALUES
(6,201,4.6,CURDATE());

COMMIT;

-- If any error occurs:
-- ROLLBACK;

-- ==========================================
-- QUERY OPTIMIZATION
-- ==========================================

-- Before Index Analysis
EXPLAIN
SELECT e.EmpName,d.DeptName,p.Rating
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Performance p ON e.EmpID=p.EmpID;

-- Create additional index
CREATE INDEX idx_performance_empid
ON Performance(EmpID);

-- After Index Analysis
EXPLAIN
SELECT e.EmpName,d.DeptName,p.Rating
FROM Employee e
JOIN Department d ON e.DeptID=d.DeptID
JOIN Performance p ON e.EmpID=p.EmpID;

-- ==========================================
-- BONUS CHALLENGE
-- ==========================================

-- View
CREATE VIEW EmployeePerformanceView AS
SELECT
    e.EmpID,
    e.EmpName,
    d.DeptName,
    p.ProjectID,
    p.Rating,
    p.ReviewDate
FROM Employee e
JOIN Department d
ON e.DeptID = d.DeptID
JOIN Performance p
ON e.EmpID = p.EmpID;

-- Stored Procedure
DELIMITER //

CREATE PROCEDURE GetTopPerformers(IN dept_name VARCHAR(50))
BEGIN
    SELECT
        e.EmpName,
        p.Rating
    FROM Employee e
    JOIN Department d
    ON e.DeptID = d.DeptID
    JOIN Performance p
    ON e.EmpID = p.EmpID
    WHERE d.DeptName = dept_name
    ORDER BY p.Rating DESC
    LIMIT 3;
END //

DELIMITER ;

-- Execute Procedure
CALL GetTopPerformers('IT');