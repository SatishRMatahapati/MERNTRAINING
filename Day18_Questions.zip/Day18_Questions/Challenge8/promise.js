const fs = require('fs').promises;

// Reading file
fs.readFile('input.txt', 'utf8')

    .then((data) => {

        console.log("File Read Successfully");
        console.log(data);

        // Writing into another file
        return fs.writeFile('output.txt', data);

    })

    .then(() => {

        console.log("File copied successfully!");

    })

    .catch((err) => {

        console.log("Error:", err.message);

    });