const fs = require('fs');

console.log("1. Program Started");

// Async file reading
fs.readFile('data.txt', 'utf8', (err, data) => {

    // This runs if there's an error
    if (err) {
        console.log("Error:", err.message);
        return;
    }
    // This runs after the file is read
    console.log("3. File Content:");
    console.log(data);

    // Bonus delay
    setTimeout(() => {
        console.log("4. Read operation completed");
    }, 2000);

});

// This runs immediately without waiting
console.log("2. This line runs before file reading completes");