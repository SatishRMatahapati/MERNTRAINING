const fs = require('fs').promises;

// Delay function
function delay(ms) {
    return new Promise((resolve) => {
        setTimeout(resolve, ms);
    });
}

// Async function
async function copyFile() {

    try {

        console.log("Reading file...");

        // Read file
        const data = await fs.readFile('input.txt', 'utf8');

        console.log("File Content:");
        console.log(data);

        // Artificial delay
        await delay(1000);

        console.log("Writing file...");

        // Write file
        await fs.writeFile('output.txt', data);

        console.log("File copied successfully!");

    }

    catch (err) {

        console.log("Error:", err.message);

    }

}

// Function call
copyFile();