import React from "react";
import "./App.css";
import BookList from "./components/BookList";

function App() {
  return (
    <div className="app">
      <h1>📚 BookVerse</h1>
      <p className="subtitle">
        Discover Popular Books From Around The World
      </p>

      <BookList />
    </div>
  );
}

export default App;