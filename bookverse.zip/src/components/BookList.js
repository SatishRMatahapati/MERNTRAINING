import React, { useState } from "react";
import BookCard from "./BookCard";

function BookList() {
  const booksData = [
    {
      id: 1,
      title: "Atomic Habits",
      author: "James Clear",
      price: 499,
    },
    {
      id: 2,
      title: "Rich Dad Poor Dad",
      author: "Robert Kiyosaki",
      price: 399,
    },
    {
      id: 3,
      title: "The Alchemist",
      author: "Paulo Coelho",
      price: 299,
    },
    {
      id: 4,
      title: "Think Like a Monk",
      author: "Jay Shetty",
      price: 450,
    },
  ];

  const [viewMode, setViewMode] = useState("grid");
  const [search, setSearch] = useState("");

  // Filter books
  const filteredBooks = booksData.filter((book) =>
    book.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      {/* Search Box */}
      <input
        type="text"
        placeholder="Search books..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="search-box"
      />

      {/* Buttons */}
      <div className="button-container">
        <button onClick={() => setViewMode("grid")}>
          Grid View
        </button>

        <button onClick={() => setViewMode("list")}>
          List View
        </button>
      </div>

      {/* Book Container */}
      <div
        className={
          viewMode === "grid"
            ? "book-container-grid"
            : "book-container-list"
        }
      >
        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              title={book.title}
              author={book.author}
              price={book.price}
              viewMode={viewMode}
            />
          ))
        ) : (
          <h3>No books found</h3>
        )}
      </div>
    </div>
  );
}

export default BookList;