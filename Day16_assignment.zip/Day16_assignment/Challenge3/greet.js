const moment = require('moment');

// Get name from command line
const name = process.argv[2];

// Get current date and time
const currentDateTime =
    moment().format("ddd MMM D YYYY, hh:mm:ss A");

// Print output
console.log(`Hello, ${name}! Today is ${currentDateTime}`);