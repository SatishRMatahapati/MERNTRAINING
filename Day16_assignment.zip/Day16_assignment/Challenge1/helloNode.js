// Node.js global objects
console.log("Node.js Version:", process.version);
console.log("Current File:", __filename);
console.log("Current Directory:", __dirname);

// Welcome message every 3 seconds
const timer = setInterval(() => {
    console.log("Welcome to Node.js");
}, 3000);

// Stop timer after 10 seconds
setTimeout(() => {
    clearInterval(timer);
    console.log("Timer stopped after 10 seconds.");
}, 10000);