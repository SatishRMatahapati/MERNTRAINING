# Employee Tracker Application

## AIM

To build a full-stack Employee Tracker application using React (Vite) and JSON Server that supports CRUD operations (Create, Read, Update, Delete), along with React Router for navigation, Context API for state management, Formik + Yup for form handling and validation, and Material UI for UI design.

---

## Features

- Display employee list (GET)
- Add new employee (POST)
- Update existing employee (PUT)
- Delete employee (DELETE)
- View employee details using dynamic routing
- Global state management using Context API
- Form validation using Formik and Yup
- Clean UI using Material UI

---

## API Endpoints (JSON Server)

- GET /employees  Get all employees  
- GET /employees/:id Get employee by ID  
- POST /employees Add employee  
- PUT /employees/:id  Update employee  
- DELETE /employees/:id  Delete employee  

---

## How to Run
db,json runs on 5001 port

### Backend (JSON Server)

npm start
it works on 5000 port
## Frontend
npm install
npm run dev

it work on 5173 port
