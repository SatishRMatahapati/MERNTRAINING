const express = require("express");
const fs = require("fs");

const router = express.Router();

const DB_PATH = "./db.json";

// Helper functions
const readDB = () => JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
const writeDB = (data) =>
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));

//GET ALL EMPLOYEES
router.get("/", (req, res) => {
  const db = readDB();
  res.json(db.employees);
});

// GET BY ID
router.get("/:id", (req, res) => {
  const db = readDB();

  const emp = db.employees.find(
    (e) => e.id == req.params.id
  );

  if (!emp) {
    return res.status(404).json({ message: "Not found" });
  }

  res.json(emp);
});


// CREATE EMPLOYEE
router.post("/", (req, res) => {
  const db = readDB();

  const newEmp = {
    id: db.employees.length
      ? db.employees[db.employees.length - 1].id + 1
      : 1,
    ...req.body
  };

  db.employees.push(newEmp);
  writeDB(db);

  res.status(201).json(newEmp);
});


// UPDATE EMPLOYEE
router.put("/:id", (req, res) => {
  const db = readDB();

  const index = db.employees.findIndex(
    (e) => e.id == req.params.id
  );

  if (index === -1) {
    return res.status(404).json({ message: "Not found" });
  }

  db.employees[index] = {
    id: Number(req.params.id),
    ...req.body
  };

  writeDB(db);

  res.json(db.employees[index]);
});


// DELETE EMPLOYEE
router.delete("/:id", (req, res) => {
  const db = readDB();

  db.employees = db.employees.filter(
    (e) => e.id != req.params.id
  );

  writeDB(db);

  res.json({ message: "Deleted successfully" });
});

module.exports = router;