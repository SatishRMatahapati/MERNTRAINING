import { createContext, useEffect, useState } from "react";

export const AppContext = createContext();

const API = "http://localhost:5000/employees";

export const AppProvider = ({ children }) => {
  const [employees, setEmployees] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchEmployees = async () => {
    setLoading(true);

    const res = await fetch(API);
    const data = await res.json();

    setEmployees(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  return (
    <AppContext.Provider
      value={{
        employees,
        setEmployees,
        fetchEmployees,
        loading
      }}
    >
      {children}
    </AppContext.Provider>
  );
};