import { useContext } from "react";
import { useParams } from "react-router-dom";
import { AppContext } from "../context/AppContext";

import { Container, Typography, Card, CardContent } from "@mui/material";

export default function UserDetailPage() {
  const { id } = useParams();
  const { employees } = useContext(AppContext);

  const emp = employees.find((e) => e.id == id);

  if (!emp) {
    return <Typography>Employee not found</Typography>;
  }

  return (
    <Container>
      <Card sx={{ marginTop: 3 }}>
        <CardContent>
          <Typography variant="h4">{emp.name}</Typography>
          <Typography variant="h6">{emp.role}</Typography>
        </CardContent>
      </Card>
    </Container>
  );
}