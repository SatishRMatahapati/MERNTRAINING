import { useContext } from "react";
import { AppContext } from "../context/AppContext";
import { Link, useNavigate } from "react-router-dom";

import {
  Container,
  Card,
  CardContent,
  Typography,
  Button,
  Stack
} from "@mui/material";

export default function HomePage() {
  const { employees, fetchEmployees } = useContext(AppContext);
  const navigate = useNavigate();

  const handleDelete = async (id) => {
    await fetch(`http://localhost:5000/employees/${id}`, {
      method: "DELETE"
    });

    fetchEmployees();
  };

  const handleUpdate = (emp) => {
    navigate(`/add`, { state: emp });
  };

  if (!employees) {
    return <Typography>Loading...</Typography>;
  }

  return (
    <Container>
      <Typography variant="h4" sx={{ mt: 2, mb: 2 }}>
        Employee Tracker
      </Typography>

      <Button
        variant="contained"
        component={Link}
        to="/add"
        sx={{ mb: 2 }}
      >
        Add Employee
      </Button>

      <Stack spacing={2}>
        {employees.map((emp) => (
          <Card key={emp.id}>
            <CardContent>
              <Typography variant="h6">
                {emp.name}
              </Typography>

              <Typography variant="body2">
                {emp.role}
              </Typography>

              <Stack direction="row" spacing={2} sx={{ mt: 2 }}>
                <Button
                  variant="outlined"
                  component={Link}
                  to={`/employee/${emp.id}`}
                >
                  View
                </Button>

                <Button
                  variant="contained"
                  color="warning"
                  onClick={() => handleUpdate(emp)}
                >
                  Update
                </Button>

                <Button
                  variant="contained"
                  color="error"
                  onClick={() => handleDelete(emp.id)}
                >
                  Delete
                </Button>
              </Stack>
            </CardContent>
          </Card>
        ))}
      </Stack>
    </Container>
  );
}