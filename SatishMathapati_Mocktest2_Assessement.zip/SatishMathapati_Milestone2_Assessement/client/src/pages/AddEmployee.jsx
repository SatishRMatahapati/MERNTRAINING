import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useContext } from "react";
import { AppContext } from "../context/AppContext";
import { useLocation, useNavigate } from "react-router-dom";

import {
  Container,
  Typography,
  TextField,
  Button,
  Stack,
  Paper
} from "@mui/material";

export default function AddEmployee() {
  const { fetchEmployees } = useContext(AppContext);
  const navigate = useNavigate();
  const location = useLocation();

  const editData = location.state;

  const API = "http://localhost:5000/employees";

  const initialValues = {
    name: editData ? editData.name : "",
    role: editData ? editData.role : ""
  };

  const validationSchema = Yup.object({
    name: Yup.string().required("Name is required"),
    role: Yup.string().required("Role is required")
  });

  const handleSubmit = async (values, { resetForm }) => {
    if (editData) {
      await fetch(`${API}/${editData.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          id: editData.id,
          ...values
        })
      });
    } else {
      await fetch(API, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(values)
      });
    }

    await fetchEmployees();
    resetForm();
    navigate("/");
  };

  return (
    <Container maxWidth="sm">
      <Paper elevation={3} sx={{ padding: 3, marginTop: 5 }}>
        <Typography variant="h5" sx={{ mb: 2 }}>
          {editData ? "Update Employee" : "Add Employee"}
        </Typography>

        <Formik
          enableReinitialize
          initialValues={initialValues}
          validationSchema={validationSchema}
          onSubmit={handleSubmit}
        >
          {({ handleChange, values }) => (
            <Form>
              <Stack spacing={2}>

                <div>
                  <TextField
                    fullWidth
                    name="name"
                    label="Employee Name"
                    value={values.name}
                    onChange={handleChange}
                  />
                  <Typography color="error" fontSize={12}>
                    <ErrorMessage name="name" />
                  </Typography>
                </div>

                <div>
                  <TextField
                    fullWidth
                    name="role"
                    label="Role"
                    value={values.role}
                    onChange={handleChange}
                  />
                  <Typography color="error" fontSize={12}>
                    <ErrorMessage name="role" />
                  </Typography>
                </div>

                <Button
                  type="submit"
                  variant="contained"
                  color={editData ? "warning" : "primary"}
                >
                  {editData ? "Update Employee" : "Add Employee"}
                </Button>

                <Button
                  variant="outlined"
                  onClick={() => navigate("/")}
                >
                  Cancel
                </Button>

              </Stack>
            </Form>
          )}
        </Formik>
      </Paper>
    </Container>
  );
}