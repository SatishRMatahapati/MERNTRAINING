import { BrowserRouter, Routes, Route } from "react-router-dom";

import HomePage from "./pages/HomePage.jsx";
import UserDetailPage from "./pages/UserDetailPage";
import AddEmployee from "./pages/AddEmployee";
import NotFound from "./pages/NotFound";

import { AppProvider } from "./context/AppContext";
import ErrorBoundary from "./components/ErrorBoundary";

function App() {
  return (
    <ErrorBoundary>
      <AppProvider>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/employee/:id" element={<UserDetailPage />} />
            <Route path="/add" element={<AddEmployee />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AppProvider>
    </ErrorBoundary>
  );
}

export default App;