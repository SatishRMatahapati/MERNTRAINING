interface Contact {
    id: number;
    name: string;
    email: string;
    phone: string;
}

class ContactManager {

    private contacts: Contact[] = [];

    addContact(contact: Contact): void {

        const existingContact = this.contacts.find(
            c => c.id === contact.id
        );

        if (existingContact) {
            alert("❌ Contact ID already exists");
            return;
        }

        this.contacts.push(contact);

        alert("✅ Contact Added Successfully");

        this.displayContacts();
    }

    viewContacts(): Contact[] {
        return this.contacts;
    }

    modifyContact(
        id: number,
        updatedData: Partial<Contact>
    ): void {

        const contact = this.contacts.find(
            c => c.id === id
        );

        if (!contact) {
            alert("❌ Contact Not Found");
            return;
        }

        Object.assign(contact, updatedData);

        alert("✅ Contact Updated Successfully");

        this.displayContacts();
    }

    deleteContact(id: number): void {

        const index = this.contacts.findIndex(
            c => c.id === id
        );

        if (index === -1) {
            alert("❌ Contact Not Found");
            return;
        }

        this.contacts.splice(index, 1);

        alert("✅ Contact Deleted Successfully");

        this.displayContacts();
    }

    displayContacts(): void {

        const tableBody = document.getElementById(
            "contactBody"
        ) as HTMLElement;

        tableBody.innerHTML = "";

        this.contacts.forEach(contact => {

            tableBody.innerHTML += `
                <tr>
                    <td>${contact.id}</td>
                    <td>${contact.name}</td>
                    <td>${contact.email}</td>
                    <td>${contact.phone}</td>
                </tr>
            `;
        });
    }
}

const manager = new ContactManager();

function getInputValues(): Contact {

    return {
        id: Number(
            (document.getElementById("id") as HTMLInputElement).value
        ),

        name: (
            document.getElementById("name") as HTMLInputElement
        ).value,

        email: (
            document.getElementById("email") as HTMLInputElement
        ).value,

        phone: (
            document.getElementById("phone") as HTMLInputElement
        ).value
    };
}

function clearInputs(): void {

    (document.getElementById("id") as HTMLInputElement).value = "";
    (document.getElementById("name") as HTMLInputElement).value = "";
    (document.getElementById("email") as HTMLInputElement).value = "";
    (document.getElementById("phone") as HTMLInputElement).value = "";
}

function addContact(): void {

    const contact = getInputValues();

    manager.addContact(contact);

    clearInputs();
}

function updateContact(): void {

    const contact = getInputValues();

    manager.modifyContact(contact.id, {
        name: contact.name,
        email: contact.email,
        phone: contact.phone
    });

    clearInputs();
}

function deleteContact(): void {

    const id = Number(
        (document.getElementById("id") as HTMLInputElement).value
    );

    manager.deleteContact(id);

    clearInputs();
}

// Make functions accessible to HTML buttons
(window as any).addContact = addContact;
(window as any).updateContact = updateContact;
(window as any).deleteContact = deleteContact;