"use strict";
class ContactManager {
    constructor() {
        this.contacts = [];
    }
    addContact(contact) {
        const existingContact = this.contacts.find(c => c.id === contact.id);
        if (existingContact) {
            alert("❌ Contact ID already exists");
            return;
        }
        this.contacts.push(contact);
        alert("✅ Contact Added Successfully");
        this.displayContacts();
    }
    viewContacts() {
        return this.contacts;
    }
    modifyContact(id, updatedData) {
        const contact = this.contacts.find(c => c.id === id);
        if (!contact) {
            alert("❌ Contact Not Found");
            return;
        }
        Object.assign(contact, updatedData);
        alert("✅ Contact Updated Successfully");
        this.displayContacts();
    }
    deleteContact(id) {
        const index = this.contacts.findIndex(c => c.id === id);
        if (index === -1) {
            alert("❌ Contact Not Found");
            return;
        }
        this.contacts.splice(index, 1);
        alert("✅ Contact Deleted Successfully");
        this.displayContacts();
    }
    displayContacts() {
        const tableBody = document.getElementById("contactBody");
        tableBody.innerHTML = "";
        this.contacts.forEach(contact => {
            tableBody.innerHTML += `
                <tr>
                    <td>${contact.id}</td>
                    <td>${contact.name}</td>
                    <td>${contact.email}</td>
                    <td>${contact.phone}</td>
                </tr>
            `;
        });
    }
}
const manager = new ContactManager();
function getInputValues() {
    return {
        id: Number(document.getElementById("id").value),
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        phone: document.getElementById("phone").value
    };
}
function clearInputs() {
    document.getElementById("id").value = "";
    document.getElementById("name").value = "";
    document.getElementById("email").value = "";
    document.getElementById("phone").value = "";
}
function addContact() {
    const contact = getInputValues();
    manager.addContact(contact);
    clearInputs();
}
function updateContact() {
    const contact = getInputValues();
    manager.modifyContact(contact.id, {
        name: contact.name,
        email: contact.email,
        phone: contact.phone
    });
    clearInputs();
}
function deleteContact() {
    const id = Number(document.getElementById("id").value);
    manager.deleteContact(id);
    clearInputs();
}
// Make functions accessible to HTML buttons
window.addContact = addContact;
window.updateContact = updateContact;
window.deleteContact = deleteContact;
