import { useState } from "react";

const useBookingForm = (initialValues, onSubmit) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues({ ...values, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // simple validation example
    const newErrors = {};
    if (!values.name) newErrors.name = "Name is required";
    if (!values.email) newErrors.email = "Email is required";

    setErrors(newErrors);

    if (Object.keys(newErrors).length === 0) {
      onSubmit(values);
      setValues(initialValues); // reset form
    }
  };

  return { values, errors, handleChange, handleSubmit };
};

export default useBookingForm;
