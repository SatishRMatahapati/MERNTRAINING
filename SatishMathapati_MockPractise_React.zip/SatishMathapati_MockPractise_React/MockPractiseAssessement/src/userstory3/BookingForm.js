import React, { useContext } from "react";
import { BookingContext } from "../../context/BookingContext";
import useBookingForm from "./hooks/useBookingForm";

export default function BookingForm() {
  const { addBooking } = useContext(BookingContext);

  const { values, errors, handleChange, handleSubmit } = useBookingForm(
    { name: "", email: "", package: "" },
    (data) => {
      addBooking(data);
      alert("Booking successful!");
    }
  );

  return (
    <div className="container">
      <h2>Booking Form</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Name:</label>
          <input
            type="text"
            name="name"
            value={values.name}
            onChange={handleChange}
            className="form-control"
          />
          {errors.name && <small className="text-danger">{errors.name}</small>}
        </div>

        <div className="mb-3">
          <label>Email:</label>
          <input
            type="email"
            name="email"
            value={values.email}
            onChange={handleChange}
            className="form-control"
          />
          {errors.email && (
            <small className="text-danger">{errors.email}</small>
          )}
        </div>

        <div className="mb-3">
          <label>Package:</label>
          <input
            type="text"
            name="package"
            value={values.package}
            onChange={handleChange}
            className="form-control"
          />
        </div>

        <button type="submit" className="btn btn-primary">
          Book Now
        </button>
      </form>
    </div>
  );
}

