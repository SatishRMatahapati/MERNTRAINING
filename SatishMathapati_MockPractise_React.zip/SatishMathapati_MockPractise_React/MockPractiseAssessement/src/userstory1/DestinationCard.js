import React, { useState } from "react";

export default function DestinationCard({ name, image, description }) {
  const [wishlisted, setWishlisted] = useState(false);

  const handleWishlist = () => setWishlisted(!wishlisted);

  return (
    <div className="card shadow-sm m-2" style={{ width: "18rem" }}>
      <img src={image} className="card-img-top" alt={name} />
      <div className="card-body text-center">
        <h5 className="card-title">{name}</h5>
        <p className="card-text">{description}</p>
        <button
          className={`btn ${wishlisted ? "btn-success" : "btn-outline-primary"}`}
          onClick={handleWishlist}
        >
          {wishlisted ? "Added :)" : "Add to Wishlist"}
        </button>
      </div>
    </div>
  );
}

