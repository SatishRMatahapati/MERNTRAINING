import React from "react";
import DestinationCard from "./DestinationCard";
import "./style.css";

export default function HomePage() {
  const destinations = [
    {
      name: "Paris",
      image: "https://imgs.search.brave.com/uaeu-ZjiGoyAQoK4tV9SfI5vBMi45o0xutFmgEbASwc/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9pbWFn/ZXMudW5zcGxhc2gu/Y29tL3Bob3RvLTE1/NTA5MjgwNjAtNGVj/Y2MxYTUxMmU0P2Zt/PWpwZyZxPTYwJnc9/MzAwMCZpeGxpYj1y/Yi00LjEuMCZpeGlk/PU0zd3hNakEzZkRC/OE1IeHpaV0Z5WTJo/OE1ueDhaV2xtWm1W/c2ZHVnVmREI4ZkRC/OGZId3c",
      description: "Romantic city of lights with art, fashion, and culture.",
    },
    {
      name: "Bali",
      image: "https://imgs.search.brave.com/NZ1cH5xa0T2Z1vD_z_gRQsqTavV-jAd8lmVZEQnef7g/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvMjE2/ODczMTY3OS9waG90/by9jYXJlZnJlZS1n/aXJsLWVuam95aW5n/LXdoaWxlLXN3aW5n/aW5nLWFnYWluc3Qt/cGFsbS10cmVlcy1v/bi12YWNhdGlvbi5q/cGc_cz02MTJ4NjEy/Jnc9MCZrPTIwJmM9/TlVEZ3NiRUtaVU85/Rk50cUtRbktjYjgx/NFZZb2prTFNSZGZs/aEkwWmJoQT0",
      description: "Beautiful beaches and temples for a relaxing getaway.",
    },
    {
      name: "Tokyo",
      image: "https://imgs.search.brave.com/YK6xeqRuQJALf51pw1uFuT-ZY0h_vAy--s0M8iKiUyY/rs:fit:500:0:1:0/g:ce/aHR0cHM6Ly9oaXBz/LmhlYXJzdGFwcHMu/Y29tL2htZy1wcm9k/L2ltYWdlcy9oaWdo/LWFuZ2xlLXZpZXct/b2YtdG9reW8tc2t5/bGluZS1hdC1kdXNr/LWphcGFuLXJveWFs/dHktZnJlZS1pbWFn/ZS0xNjY0MzA5OTI2/LmpwZz9jcm9wPTAu/NjY4eHc6MS4wMHho/OzAuMDQ5N3h3LDAm/cmVzaXplPTY0MDoq",
      description: "A perfect blend of tradition and cutting-edge technology.",
    },
  ];

  return (
    <div className="d-flex flex-wrap justify-content-center">
      {destinations.map((dest, index) => (
        <DestinationCard
          key={index}
          name={dest.name}
          image={dest.image}
          description={dest.description}
        />
      ))}
    </div>
  );
}

