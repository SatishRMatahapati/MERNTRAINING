import React, { useEffect, useState } from "react";

export default function PackageList() {
  const [packages, setPackages] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("http://localhost:5000/packages")
      .then((res) => res.json())
      .then((data) => {
        setPackages(data);
        setLoading(false);
      })
      .catch((err) => console.error("Error fetching packages:", err));
  }, []);

  if (loading) return <p>Loading packages...</p>;

  return (
    <div className="container my-4">
      <h2>Travel Packages</h2>
      <div className="row">
        {packages.map((pkg) => (
          <div key={pkg.id} className="col-md-4 mb-3">
            <div className="card h-100 p-3">
              <h5>{pkg.name}</h5>
              <p>{pkg.description}</p>
              <strong>Price: ${pkg.price}</strong>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
