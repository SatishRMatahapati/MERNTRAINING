import React from "react";
import { BrowserRouter as Router, Routes, Route, Link, Navigate } from "react-router-dom";
import HomePage from "./userstory1/HomePage";
import PackageList from "./userstory2/PackageList";
import BookingForm from "./userstory3/BookingForm";
import { BookingProvider } from "./context/BookingContext";
import ErrorBoundary from "./components/ErrorBoundary";
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <BookingProvider>
      <ErrorBoundary>
        <Router>
          <header className="bg-primary text-white p-3">
            <div className="container d-flex justify-content-between">
              <h3 className="mb-0">Travel Booking</h3>
              <nav>
                <Link to="/home" className="text-white me-3">Home</Link>
                <Link to="/packages" className="text-white me-3">Packages</Link>
                <Link to="/booking" className="text-white">Booking</Link>
              </nav>
            </div>
          </header>

          <main className="container my-4">
            <Routes>
              <Route path="/" element={<Navigate to="/home" replace />} />
              <Route path="/home" element={<HomePage />} />
              <Route path="/packages" element={<PackageList />} />
              <Route path="/booking" element={<BookingForm />} />
              <Route path="*" element={<div>Page not found</div>} />
            </Routes>
          </main>

          <footer className="bg-light text-center py-3">
            <small>© 2025 Travel Booking — Mock Practice</small>
          </footer>
        </Router>
      </ErrorBoundary>
    </BookingProvider>
  );
}

export default App;
