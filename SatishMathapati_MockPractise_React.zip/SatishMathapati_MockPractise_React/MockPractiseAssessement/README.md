# Travel Booking Application

## About Project

This is a simple Travel Booking Application developed using React.
The project is created to practice React concepts like components, routing, hooks, API fetching, form validation, Context API, and reducers.

The application allows users to:

* View travel destinations
* View travel packages
* Fill booking form

---

## Features

### User Story 1

* Displays travel destination cards
* Uses reusable components
* Simple responsive UI

### User Story 2

* Displays package data from JSON Server
* Uses useEffect for fetching data

### User Story 3

* Booking form with validation
* Uses Formik and Yup
* Uses Context API and reducers
* Custom hook for form handling

---

## Technologies Used

* React
* Bootstrap
* React Router DOM
* Formik
* Yup
* JSON Server
* JavaScript

---

---

## How to Run the Project

### Step 1

Extract the ZIP file.

### Step 2

Open the main project folder in VS Code.

### Step 3

Open terminal and install dependencies:

npm install

### Step 4

Run the React application:

npm start

The project will run on:

[http://localhost:3000](http://localhost:3000)

---

## Run JSON Server

Open another terminal in the same folder and run:

npm install -g json-server

Then run:

json-server --watch src/userstory2/db.json --port 5000

JSON Server will run on:

[http://localhost:5000/packages](http://localhost:5000/packages)

---

## Important Note

Keep both terminals running:

* One for React app
* One for JSON Server

---


