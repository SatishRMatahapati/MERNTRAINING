// Middleware to validate course ID
function validateCourseId(req, res, next) {

    const courseId = req.params.id;

    if (isNaN(courseId)) {

        return res.status(400).json({
            error: "Invalid course ID"
        });

    }

    next();
}

module.exports = validateCourseId;