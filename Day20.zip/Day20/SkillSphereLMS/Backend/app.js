const express = require("express");

const app = express();

// Import Routes
const challenge1 = require("./routes/challenge1");
const challenge2 = require("./routes/challenge2");
const challenge3 = require("./routes/challenge3");


// Challenge 1 root route
app.use("/", challenge1);

// Challenge 2 route
app.use("/challenge2/courses", challenge2);

// Challenge 3
app.use("/challenge3/courses", challenge3);


const PORT = 4000;

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});