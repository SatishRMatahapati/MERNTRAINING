// Challenge 2: Course Details Endpoint
const express = require("express");

const router = express.Router();

router.get("/:id", (req, res) => {

    const courseId = req.params.id;

    res.json({
        id: courseId,
        name: "React Mastery",
        duration: "6 weeks"
    });

});

module.exports = router;