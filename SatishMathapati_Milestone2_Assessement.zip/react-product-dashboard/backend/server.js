const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 5000;
const DATA_FILE = path.join(__dirname, 'data', 'products.json');

app.use(cors());
app.use(bodyParser.json());

// Helper to read/write JSON file
function readProducts() {
  try {
    const raw = fs.readFileSync(DATA_FILE);
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error reading products:', err);
    return [];
  }
}

function writeProducts(products) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2));
    return true;
  } catch (err) {
    console.error('Error writing products:', err);
    return false;
  }
}

// GET /api/products
app.get('/api/products', (req, res) => {
  try {
    const products = readProducts();
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to read products' });
  }
});

// GET /api/products/:id
app.get('/api/products/:id', (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    const products = readProducts();
    const product = products.find(p => p.id === id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(product);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to read product' });
  }
});

// POST /api/products
app.post('/api/products', (req, res) => {
  try {
    const products = readProducts();
    const { name, price, category, description } = req.body;

    // Simple validation
    if (!name || !price || !category) {
      return res.status(400).json({ error: 'name, price and category are required' });
    }

    const newId = products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;
    const newProduct = {
      id: newId,
      name,
      price: parseFloat(price),
      category,
      description: description || ''
    };

    products.push(newProduct);
    const ok = writeProducts(products);
    if (!ok) {
      return res.status(500).json({ error: 'Failed to save product' });
    }

    res.status(201).json(newProduct);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to add product' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
