import React from 'react';
import ProductCard from './ProductCard';
import { ProductContext } from '../context/ProductContext';

class ProductList extends React.Component {
  static contextType = ProductContext;

  render() {
    const { products, loading, error } = this.context;

    if (loading) return <div>Loading products...</div>;
    if (error) return <div className="alert alert-danger">{error}</div>;

    return (
      <div>
        <h2>Products</h2>
        <div className="card-grid">
          {products.map(p => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </div>
    );
  }
}

export default ProductList;
