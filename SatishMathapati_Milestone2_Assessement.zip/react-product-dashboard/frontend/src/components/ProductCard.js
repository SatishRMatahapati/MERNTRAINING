import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function ProductCard({ product }) {
  const [fav, setFav] = useState(false);

  const toggleFav = () => setFav(prev => !prev);

  return (
    <div className="card h-100">
      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{product.name}</h5>
        <h6 className="card-subtitle mb-2 text-muted">{product.category}</h6>
        <p className="card-text text-truncate">{product.description}</p>
        <div className="mt-auto d-flex justify-content-between align-items-center">
          <div>
            <strong>₹{product.price}</strong>
          </div>
          <div>
            <button className={`btn btn-sm ${fav ? 'btn-warning' : 'btn-outline-secondary'} me-2`} onClick={toggleFav}>
              {fav ? '★ Fav' : '☆ Fav'}
            </button>
            <Link to={`/products/${product.id}`} className="btn btn-sm btn-primary">Details</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductCard;
