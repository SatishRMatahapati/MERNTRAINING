import React, { useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { ProductContext } from '../context/ProductContext';

const validationSchema = Yup.object().shape({
  name: Yup.string().required('Name is required'),
  price: Yup.number().typeError('Price must be a number').positive('Price must be positive').required('Price is required'),
  category: Yup.string().required('Category is required'),
  description: Yup.string().max(500, 'Description too long'),
});

function AddProductForm() {
  const { addProduct } = useContext(ProductContext);
  const navigate = useNavigate();

  return (
    <div>
      <h2>Add Product</h2>
      <Formik
        initialValues={{ name: '', price: '', category: '', description: '' }}
        validationSchema={validationSchema}
        onSubmit={async (values, { setSubmitting, setStatus, resetForm }) => {
          setStatus(null);
          try {
            await addProduct(values);
            setStatus({ success: 'Product added successfully!' });
            resetForm();
            // navigate to product list after small delay
            setTimeout(() => navigate('/'), 800);
          } catch (err) {
            setStatus({ error: err.message || 'Failed to add product' });
          } finally {
            setSubmitting(false);
          }
        }}
      >
        {({ isSubmitting, status }) => (
          <Form>
            {status && status.success && <div className="alert alert-success">{status.success}</div>}
            {status && status.error && <div className="alert alert-danger">{status.error}</div>}

            <div className="mb-3">
              <label className="form-label">Name</label>
              <Field name="name" className="form-control" />
              <div className="text-danger"><ErrorMessage name="name" /></div>
            </div>

            <div className="mb-3">
              <label className="form-label">Price</label>
              <Field name="price" className="form-control" />
              <div className="text-danger"><ErrorMessage name="price" /></div>
            </div>

            <div className="mb-3">
              <label className="form-label">Category</label>
              <Field as="select" name="category" className="form-select">
                <option value="">Select</option>
                <option value="Electronics">Electronics</option>
                <option value="Kitchen">Kitchen</option>
                <option value="Sports">Sports</option>
                <option value="Books">Books</option>
              </Field>
              <div className="text-danger"><ErrorMessage name="category" /></div>
            </div>

            <div className="mb-3">
              <label className="form-label">Description</label>
              <Field as="textarea" name="description" className="form-control" />
              <div className="text-danger"><ErrorMessage name="description" /></div>
            </div>

            <button type="submit" className="btn btn-success" disabled={isSubmitting}>
              {isSubmitting ? 'Submitting...' : 'Add Product'}
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
}

export default AddProductForm;
