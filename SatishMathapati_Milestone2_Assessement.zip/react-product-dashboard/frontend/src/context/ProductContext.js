import React, { createContext, useState, useEffect } from 'react';
import { fetchProducts as apiFetchProducts, addProduct as apiAddProduct } from '../utils/api';

export const ProductContext = createContext();

export const ProductProvider = ({ children }) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchProducts = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await apiFetchProducts();
      setProducts(data);
    } catch (err) {
      setError('Failed to fetch products');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const addProduct = async (product) => {
    try {
      const created = await apiAddProduct(product);
      // Update global list
      setProducts(prev => [...prev, created]);
      return created;
    } catch (err) {
      console.error('Failed to add product', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <ProductContext.Provider value={{ products, loading, error, fetchProducts, addProduct }}>
      {children}
    </ProductContext.Provider>
  );
};
