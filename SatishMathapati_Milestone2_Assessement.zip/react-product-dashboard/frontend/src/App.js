import React, { Suspense, lazy } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import ProductList from './components/ProductList';
import AddProductForm from './components/AddProductForm';

// Lazy load ProductDetail (Bonus)
const ProductDetail = lazy(() => import('./components/ProductDetail'));

function App() {
  return (
    <div className="container my-4">
      <header className="d-flex justify-content-between align-items-center mb-4">
        <h1>Product Dashboard</h1>
        <nav>
          <Link to="/" className="btn btn-outline-primary me-2">Products</Link>
          <Link to="/add" className="btn btn-primary">Add Product</Link>
        </nav>
      </header>

      <Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route path="/" element={<ProductList />} />
          <Route path="/add" element={<AddProductForm />} />
          <Route path="/products/:id" element={<ProductDetail />} />
        </Routes>
      </Suspense>
    </div>
  );
}

export default App;
