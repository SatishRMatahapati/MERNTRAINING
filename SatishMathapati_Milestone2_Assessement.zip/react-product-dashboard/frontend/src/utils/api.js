const baseUrl = '/api/products'; // proxied to backend via package.json proxy

export async function fetchProducts() {
  const res = await fetch(baseUrl);
  if (!res.ok) throw new Error('Network response was not ok');
  return res.json();
}

export async function fetchProductById(id) {
  const res = await fetch(`${baseUrl}/${id}`);
  if (!res.ok) {
    if (res.status === 404) throw new Error('Not found');
    throw new Error('Network response was not ok');
  }
  return res.json();
}

export async function addProduct(product) {
  const res = await fetch(baseUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(product),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to add product');
  }
  return res.json();
}
