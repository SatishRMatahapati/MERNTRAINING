const EventEmitter = require('events');

const event = new EventEmitter();

// Event Listener for Login
event.on("userLoggedIn", (name) => {
    console.log(`User ${name} logged in.`);
});

// Event Listener for Logout
event.on("userLoggedOut", (name) => {
    console.log(`User ${name} logged out.`);
});

// Event Listener for Session Expired
event.on("sessionExpired", (name) => {
    console.log(`Session expired for ${name}`);
});

// Trigger Events
event.emit("userLoggedIn", "Satish");

setTimeout(() => {
    event.emit("sessionExpired", "Satish");
}, 5000);

setTimeout(() => {
    event.emit("userLoggedOut", "Satish");
}, 6000);


//nned to implement a even like login in html and logout also
