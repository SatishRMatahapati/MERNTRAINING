const fs = require('fs').promises;
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Enter your feedback: ", async (input) => {
    try {
        // Write data into file
        await fs.writeFile('feedback.txt', input);

        console.log("Data written successfully.");
        console.log("Reading file...");

        // Read file content
        const data = await fs.readFile('feedback.txt', 'utf8');

        console.log(data);
    } catch (error) {
        console.log("Error:", error);
    }

    rl.close();
});


// Callbacks are functions passed as arguments to be executed after an asynchronous operation completes

// promises are objects representing the eventual completion or failure of an asynchronous 
// operation and its resulting value