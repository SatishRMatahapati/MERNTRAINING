//express server without query parameters

const express = require("express");

const app = express();

const PORT = 4000;

// Home Route
app.get("/", (req, res) => {
    res.send("Welcome to Express Server");
});

// Bonus Route
app.get("/status", (req, res) => {
    res.json({
        server: "running",
        uptime: "OK"
    });
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});