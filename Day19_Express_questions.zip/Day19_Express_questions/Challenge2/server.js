//express server with and without query parameters


const express = require("express");

const app = express();

const PORT = 4000;

// Home Route
app.get("/", (req, res) => {
    res.send("Welcome to Express Server");
});

// Products Route
app.get("/products", (req, res) => {

    const productName = req.query.name;

    if (productName) {
        res.json({
            query: productName
        });
    } else {
        res.send("Please provide a product name");
    }

});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});