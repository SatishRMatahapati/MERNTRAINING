const express = require("express");

const app = express();

const PORT = 4000;


// Middleware
app.use(express.json());


// In-Memory Database
let books = [

    { id: 1, title: "1984", author: "Orwell" },

    { id: 2, title: "The Alchemist", author: "Coelho" }

];


// HOME ROUTE
app.get("/", (req, res) => {

    res.send("Book API Running");

});


// GET ALL BOOKS
app.get("/books", (req, res) => {

    res.json(books);

});


// GET BOOK BY ID
app.get("/books/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const book = books.find(b => b.id === id);

    // Validation
    if (!book) {

        return res.status(404).json({
            error: "Book not found"
        });

    }

    res.json(book);

});


// ADD NEW BOOK
app.post("/books", (req, res) => {

    const { title, author } = req.body;

    // Validation
    if (!title || !author) {

        return res.status(400).json({
            error: "Title and Author are required"
        });

    }

    const newBook = {

        id: books.length + 1,

        title,

        author

    };

    books.push(newBook);

    res.status(201).json({

        message: "Book added successfully",

        book: newBook

    });

});


// UPDATE BOOK
app.put("/books/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const { title, author } = req.body;

    const book = books.find(b => b.id === id);

    // Validation
    if (!book) {

        return res.status(404).json({
            error: "Book not found"
        });

    }

    // Update Values
    if (title) {
        book.title = title;
    }

    if (author) {
        book.author = author;
    }

    res.json({

        message: "Book updated successfully",

        book

    });

});


// DELETE BOOK
app.delete("/books/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const book = books.find(b => b.id === id);

    // Validation
    if (!book) {

        return res.status(404).json({
            error: "Book not found"
        });

    }

    books = books.filter(b => b.id !== id);

    res.json({

        message: "Book deleted successfully"

    });

});


// START SERVER
app.listen(PORT, () => {

    console.log(`Server running on port ${PORT}`);

});