const express = require("express");

const app = express();

const PORT = 4000;

// Custom Middleware
app.use((req, res, next) => {

    const currentTime = new Date().toLocaleString();

    console.log(`[${req.method}] ${req.url} - ${currentTime}`);

    next();

});

// Routes
app.get("/", (req, res) => {
    res.send("Welcome to Express Server");
});

app.get("/status", (req, res) => {
    res.json({
        server: "running"
    });
});

app.get("/products", (req, res) => {
    res.json({
        products: []
    });
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});