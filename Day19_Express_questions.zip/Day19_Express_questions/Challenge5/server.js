//import express and create app instance
const express = require("express");

const app = express();



//define port
const PORT = 4000;


// Middleware to parse JSON bodies
app.use(express.json());


// Logging Middleware (BONUS)
app.use((req, res, next) => {

    console.log(`[${req.method}] ${req.url}`);

    next();

});

// Use Router for /books routes
app.use("/books", bookRouter);


// Home Route for testing
app.get("/", (req, res) => {

    res.send("Modular Book API Running");

});


// 404 Handler for undefined routes
app.use((req, res) => {

    res.status(404).json({
        error: "Route not found"
    });

});


// Global Error Handler (BONUS) 
app.use((err, req, res, next) => {

    console.error(err.stack);

    res.status(500).json({
        error: "Internal Server Error"
    });

});


// Start Server on defined port
app.listen(PORT, () => {

    console.log(`Server running on port ${PORT}`);

});