const express = require("express");

const router = express.Router();


// In-memory Database
let books = [

    { id: 1, title: "1984", author: "Orwell" },

    { id: 2, title: "The Alchemist", author: "Coelho" }

];


// GET ALL BOOKS
router.get("/", (req, res) => {

    res.json(books);

});


// GET SINGLE BOOK
router.get("/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const book = books.find(b => b.id === id);

    if (!book) {

        return res.status(404).json({
            error: "Book not found"
        });

    }

    res.json(book);

});


// ADD BOOK
router.post("/", (req, res) => {

    const { title, author } = req.body;

    // Validation
    if (!title || !author) {

        return res.status(400).json({
            error: "Title and Author are required"
        });

    }

    const newBook = {

        id: books.length + 1,

        title,

        author

    };

    books.push(newBook);

    res.status(201).json({

        message: "Book added successfully",

        book: newBook

    });

});


// UPDATE BOOK
router.put("/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const { title, author } = req.body;

    const book = books.find(b => b.id === id);

    if (!book) {

        return res.status(404).json({
            error: "Book not found"
        });

    }

    if (title) {
        book.title = title;
    }

    if (author) {
        book.author = author;
    }

    res.json({

        message: "Book updated successfully",

        book

    });

});


// DELETE BOOK
router.delete("/:id", (req, res) => {

    const id = parseInt(req.params.id);

    const book = books.find(b => b.id === id);

    if (!book) {

        return res.status(404).json({
            error: "Book not found"
        });

    }

    books = books.filter(b => b.id !== id);

    res.json({
        message: "Book deleted successfully"
    });

});


module.exports = router;