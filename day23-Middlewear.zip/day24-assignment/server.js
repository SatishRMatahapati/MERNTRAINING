const express = require("express");
const multer = require("multer");
const path = require("path");
const http = require("http");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = 3000;

/* ==========================
   MULTER CONFIGURATION
========================== */

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "uploads/");
    },

    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

const fileFilter = (req, file, cb) => {

    if (file.mimetype === "application/pdf") {
        cb(null, true);
    } else {
        cb(new Error("Only PDF files are allowed"));
    }
};

const upload = multer({
    storage,
    fileFilter
});

/* ==========================
   CHALLENGE 1
   FILE UPLOAD API
========================== */

app.post("/upload", upload.single("pdf"), (req, res) => {

    if (!req.file) {
        return res.status(400).send("No file uploaded");
    }

    res.send(
        `File uploaded successfully: ${req.file.filename}`
    );
});

/* ==========================
   CHALLENGE 2
   STATIC FILE SERVING
========================== */

app.use(
    "/materials",
    express.static(path.join(__dirname, "uploads"))
);

/* ==========================
   CHAT PAGE
========================== */

app.use(express.static("public"));

/* ==========================
   CHALLENGE 3
   SOCKET.IO CHAT
========================== */

io.on("connection", (socket) => {

    console.log("User Connected");

    socket.on("chatMessage", (message) => {

        console.log("Message:", message);

        io.emit("chatMessage", message);
    });

    socket.on("disconnect", () => {

        console.log("User Disconnected");
    });
});

/* ==========================
   START SERVER
========================== */

server.listen(PORT, () => {

    console.log(
        `Server Running On http://localhost:${PORT}`
    );
});