const API = "http://localhost:3000/customers";

const customerList = document.getElementById("customerList");

let editId = null;

// -------------------- READ (GET ALL) --------------------
async function getCustomers() {

    try {

        const response = await fetch(API);
        const customers = await response.json();

        displayCustomers(customers);

    } catch (error) {
        console.log("Error fetching data:", error);
    }
}

// -------------------- DISPLAY --------------------
function displayCustomers(customers) {

    customerList.innerHTML = "";

    customers.forEach(customer => {

        customerList.innerHTML += `
            <div class="card">

                <h4>${customer.name}</h4>
                <p>${customer.email}</p>

                <button class="btn btn-warning btn-sm editBtn" data-id="${customer.id}">
                    Edit
                </button>

                <button class="btn btn-danger btn-sm deleteBtn" data-id="${customer.id}">
                    Delete
                </button>

            </div>
        `;
    });

    attachEvents();
}

// -------------------- CREATE + UPDATE --------------------
document.getElementById("customerForm")
.addEventListener("submit", async (e) => {

    e.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;

    // UPDATE
    if (editId) {

        await fetch(`${API}/${editId}`, {

            method: "PUT",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                id: editId,
                name: name,
                email: email
            })

        });

        editId = null;

    } 
    // CREATE
    else {

        await fetch(API, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                name: name,
                email: email
            })

        });
    }

    document.getElementById("customerForm").reset();

    getCustomers();
});

// -------------------- ATTACH BUTTON EVENTS --------------------
function attachEvents() {

    // EDIT
    document.querySelectorAll(".editBtn").forEach(btn => {

        btn.addEventListener("click", async () => {

            const id = btn.getAttribute("data-id");

            const res = await fetch(`${API}/${id}`);
            const customer = await res.json();

            document.getElementById("name").value = customer.name;
            document.getElementById("email").value = customer.email;

            editId = customer.id;
        });

    });

    // DELETE
    document.querySelectorAll(".deleteBtn").forEach(btn => {

        btn.addEventListener("click", async () => {

            const id = btn.getAttribute("data-id");

            await fetch(`${API}/${id}`, {
                method: "DELETE"
            });

            getCustomers();

        });

    });

}

// -------------------- INITIAL LOAD --------------------
getCustomers();