const eventContainer = document.getElementById("eventContainer");
const categoryFilter = document.getElementById("categoryFilter");

let allEvents = [];

// API (JSON SERVER)
const API = "http://localhost:3001/events";
// Fetch Events
const fetchEvents = async () => {

    try {

        const response = await fetch(API);

        if (!response.ok) {
            throw new Error("Failed to fetch events");
        }

        const data = await response.json();

        allEvents = data;

        displayEvents(allEvents);

    }
    catch (error) {

        eventContainer.innerHTML = `
            <h3 class="text-danger">
                ${error.message}
            </h3>
        `;

    }

};

// Display Events
const displayEvents = (events) => {

    eventContainer.innerHTML = "";

    events.forEach((event) => {

        const { name, category, date, location } = event;

        const card = `
            <div class="col-md-4 event-card">

                <div class="card shadow">

                    <div class="card-body">

                        <h5 class="card-title">
                            ${name}
                        </h5>

                        <p class="card-text">
                            Category: ${category}
                        </p>

                        <p class="card-text">
                            Date: ${date}
                        </p>

                        <p class="card-text">
                            Location: ${location}
                        </p>

                    </div>

                </div>

            </div>
        `;

        eventContainer.innerHTML += card;

    });

};

// Filter Events
categoryFilter.addEventListener("change", () => {

    const selectedCategory = categoryFilter.value;

    if (selectedCategory === "All") {

        displayEvents(allEvents);

    } else {

        const filteredEvents = allEvents.filter(
            (event) => event.category === selectedCategory
        );

        displayEvents(filteredEvents);

    }

});

// Load Data
fetchEvents();