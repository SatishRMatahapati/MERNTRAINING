
Mock Practice Assessment – Front-End & Database Integration
============================================================

PROJECT TITLE
-------------
Event Management System with Dashboard & CRUD Operations

============================================================

TECHNOLOGIES USED
------------------
- HTML5
- CSS3
- Bootstrap 5
- JavaScript (ES6)
- Fetch API
- JSON Server (Mock Backend)

============================================================

PROJECT DESCRIPTION
--------------------
This project is a web-based Event Management System that demonstrates frontend development skills and basic backend integration using a mock REST API (JSON Server).

It contains:
1. A responsive homepage for event management
2. An interactive event dashboard with filtering
3. A CRUD-based customer management system using JSON Server

============================================================

USER STORY 1 – EVENT MANAGEMENT HOMEPAGE
-----------------------------------------
Features:
- Responsive homepage using HTML, CSS, Bootstrap
- Navigation bar
- Image carousel for events
- Event cards
- Registration form with validation
- Modal popup for event details

Concepts Used:
- Semantic HTML5
- Bootstrap Grid System
- Form validation using JavaScript
- UI responsiveness

============================================================

USER STORY 2 – EVENT DASHBOARD
--------------------------------
Features:
- Event data fetched using Fetch API
- Data loaded from JSON Server (or JSON file)
- Dynamic rendering of event cards
- Filter events by category (Music, Tech, Food, Business)
- Async/Await for API calls
- Error handling implemented

API Used:
http://localhost:3001/events

Concepts Used:
- ES6 features (let, const, arrow functions, destructuring)
- Fetch API
- Async/Await
- DOM Manipulation
- Array filtering

============================================================

BONUS – CUSTOMER CRUD SYSTEM (JSON SERVER)
-------------------------------------------
Features:
- Create customer (POST)
- Read customer data (GET)
- Update customer details (PUT)
- Delete customer (DELETE)
- Real-time UI updates

API Used:
http://localhost:3001/customers

How to Run JSON Server:
1. Install JSON Server:
   npm install -g json-server

2. Run server:
   json-server --watch db.json --port 3001

3. Open:
   crud.html using Live Server

Concepts Used:
- REST API simulation
- CRUD operations
- Event handling
- Dynamic DOM updates

============================================================

HOW TO RUN PROJECT
-------------------
1. Open userstory1/index.html in browser
2. Open userstory2/dashboard.html using Live Server
3. Run JSON Server for bonus:
   json-server --watch db.json --port 3001
4. Open bonus/crud.html using Live Server

============================================================

OUTPUTS INCLUDED
-----------------
- Homepage UI screenshot
- Event dashboard with filtering
- CRUD operations (Add, Edit, Delete)

============================================================

NOTES
-----
- JSON Server is running before using dashboard and CRUD
- All files are tested and working
- Screenshots are included in /screenshots folder

============================================================

END OF PROJECT
---------------