
# FitTrack Assessment

Backend + frontend mock assessment for a fitness program enrollment platform.

**Project**: simple Express + MongoDB backend with a React-like frontend (starter files).

**Key points**
- **Seed data**: sample programs are provided in [backend/seed/seedPrograms.js](backend/seed/seedPrograms.js#L1-L27).
- **Backend**: Express server in [backend/server.js](backend/server.js) exposing program and enrollment routes.
- **Tests**: backend tests in [backend/tests](backend/tests) using Mocha, Chai and SuperTest.

**Repository structure**
- [backend](backend)
- [frontend](frontend)
- [postman/FitTrack_Postman_Collection.json](postman/FitTrack_Postman_Collection.json)

**Prerequisites**
- Node.js (v16+ recommended)
- npm
- MongoDB instance (local or hosted). Set `MONGO_URI` in a `.env` file or rely on the default `mongodb://127.0.0.1:27017/fittrack`.

Backend setup

1. Install dependencies and start the server:

```bash
cd backend
npm install
npm start
```

2. Development mode (auto-reload):

```bash
npm run dev
```

3. Seed sample programs into the database (runs `backend/seed/seedPrograms.js`):

```bash
cd backend
npm run seed
```

Notes: the seed script uses `MONGO_URI` from the environment or defaults to `mongodb://127.0.0.1:27017/fittrack`.

Testing

Run backend tests:

```bash
cd backend
npm test
```

Frontend setup

1. Install and run the frontend dev server:

```bash
cd frontend
npm install
npm start
```

API Endpoints (high level)

- `GET /programs` — list available programs
- `POST /enroll` — create a program enrollment (validated)

Refer to the route implementations in [backend/routes](backend/routes) for details.

there are schemas created and i attached the snip of the schemas in the screenshot folder


Author: Satish