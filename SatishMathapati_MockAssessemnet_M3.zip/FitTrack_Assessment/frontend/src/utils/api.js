const BASE = '/api'; // proxied to backend in package.json

export async function fetchPrograms() {
  const res = await fetch(`${BASE}/programs`);
  if (!res.ok) {
    const body = await res.json().catch(()=>null);
    const err = new Error(body?.message || 'Failed to fetch programs');
    err.status = res.status;
    throw err;
  }
  return res.json();
}

export async function enroll(userId, programId) {
  const res = await fetch(`${BASE}/enroll`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, programId })
  });
  const body = await res.json().catch(()=>null);
  if (!res.ok) {
    const err = new Error(body?.message || 'Enrollment failed');
    err.status = res.status;
    throw err;
  }
  return body;
}

export async function createProgram(program) {
  const res = await fetch(`${BASE}/programs`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(program)
  });
  const body = await res.json().catch(()=>null);
  if (!res.ok) {
    const err = new Error(body?.message || 'Program creation failed');
    err.status = res.status;
    throw err;
  }
  return body;
}

export async function fetchUsers() {
  const res = await fetch(`${BASE}/users`);
  if (!res.ok) {
    const body = await res.json().catch(()=>null);
    const err = new Error(body?.message || 'Failed to fetch users');
    err.status = res.status;
    throw err;
  }
  return res.json();
}

export async function createUser(user) {
  const res = await fetch(`${BASE}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(user)
  });
  const body = await res.json().catch(()=>null);
  if (!res.ok) {
    const err = new Error(body?.message || 'User creation failed');
    err.status = res.status;
    throw err;
  }
  return body;
}

export async function fetchEnrollments(userId) {
  const res = await fetch(`${BASE}/enroll?userId=${encodeURIComponent(userId)}`);
  if (!res.ok) {
    const body = await res.json().catch(()=>null);
    const err = new Error(body?.message || 'Failed to fetch enrollments');
    err.status = res.status;
    throw err;
  }
  return res.json();
}
