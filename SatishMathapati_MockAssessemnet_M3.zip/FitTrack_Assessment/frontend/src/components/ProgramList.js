import React, { useEffect, useState } from 'react';
import { fetchPrograms, enroll, createProgram, fetchUsers, createUser, fetchEnrollments } from '../utils/api';

function ProgramCard({ program, onEnroll, enrolling }) {
  return (
    <div className="card h-100">
      <div className="card-body d-flex flex-column">
        <h5 className="card-title">{program.name}</h5>
        <h6 className="card-subtitle mb-2 text-muted">{program.category} • {program.level}</h6>
        <p className="card-text">{program.programId}</p>
        <div className="mt-auto d-flex justify-content-between align-items-center">
          <strong>₹{program.price}</strong>
          <button className="btn btn-primary btn-sm" onClick={() => onEnroll(program.programId)} disabled={enrolling}>{enrolling ? 'Enrolling...' : 'Enroll'}</button>
        </div>
      </div>
    </div>
  );
}

export default function ProgramList() {
  const [programs, setPrograms] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [enrolledPrograms, setEnrolledPrograms] = useState([]);
  const [message, setMessage] = useState(null);
  const [enrollingId, setEnrollingId] = useState(null);
  const [formError, setFormError] = useState(null);
  const [createMessage, setCreateMessage] = useState(null);
  const [creating, setCreating] = useState(false);
  const [newProgram, setNewProgram] = useState({
    programId: '',
    name: '',
    category: '',
    level: 'Beginner',
    price: ''
  });
  const [users, setUsers] = useState([]);
  const [selectedUser, setSelectedUser] = useState('');
  const [creatingUser, setCreatingUser] = useState(false);
  const [newUser, setNewUser] = useState({ userId: '', name: '', email: '' });
  const [userError, setUserError] = useState(null);
  const [userMessage, setUserMessage] = useState(null);

  useEffect(()=>{
    async function load() {
      try {
        setLoading(true);
        const res = await fetchPrograms();
        // response shape: { success, message, data }
        setPrograms(res.data || []);
        const ures = await fetchUsers().catch(()=>({ data: [] }));
        setUsers(ures.data || []);
        if ((ures.data || []).length > 0) setSelectedUser(ures.data[0].userId);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  // when selectedUser changes, load their enrollments
  useEffect(() => {
    async function loadEnrollments() {
      if (!selectedUser) {
        setEnrolledPrograms([]);
        return;
      }
      try {
        const res = await fetchEnrollments(selectedUser);
        // res.data is array of program objects
        const ids = (res.data || []).map(p => p.programId);
        setEnrolledPrograms(ids);
      } catch (err) {
        // show no enrollments silently
        setEnrolledPrograms([]);
      }
    }
    loadEnrollments();
  }, [selectedUser]);

  const handleEnroll = async (programId) => {
    setMessage(null);
    setEnrollingId(programId);
    try {
      if (!selectedUser) throw new Error('Select or create a user before enrolling');
      const res = await enroll(selectedUser, programId);
      setMessage({ type: 'success', text: res.message || 'Enrolled' });
      // refresh enrollments for current user
      const eres = await fetchEnrollments(selectedUser).catch(()=>({ data: [] }));
      const ids = (eres.data || []).map(p => p.programId);
      setEnrolledPrograms(ids);
    } catch (err) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setEnrollingId(null);
    }
  };

  const handleCreateChangeUser = (e) => {
    const { name, value } = e.target;
    setNewUser(prev => ({ ...prev, [name]: value }));
  };

  const handleCreateUser = async (e) => {
    e.preventDefault();
    setUserError(null);
    setUserMessage(null);
    setCreatingUser(true);
    try {
      const res = await createUser(newUser);
      setUsers(prev => [res.data, ...prev]);
      setUserMessage('User created successfully.');
      setSelectedUser(res.data.userId);
      setNewUser({ userId: '', name: '', email: '' });
    } catch (err) {
      setUserError(err.message);
    } finally {
      setCreatingUser(false);
    }
  };

  const handleCreateChange = (e) => {
    const { name, value } = e.target;
    setNewProgram(prev => ({ ...prev, [name]: value }));
  };

  const handleCreateProgram = async (e) => {
    e.preventDefault();
    setFormError(null);
    setCreateMessage(null);
    setCreating(true);

    try {
      const programToCreate = {
        ...newProgram,
        price: Number(newProgram.price)
      };

      const res = await createProgram(programToCreate);
      setPrograms(prev => [res.data, ...prev]);
      setCreateMessage('Program created successfully.');
      setNewProgram({ programId: '', name: '', category: '', level: 'Beginner', price: '' });
    } catch (err) {
      setFormError(err.message);
    } finally {
      setCreating(false);
    }
  };

  if (loading) return <div>Loading programs...</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;

  return (
    <div className="container">
      <header className="d-flex justify-content-between align-items-center mb-4">
        <h1>FitTrack Programs</h1>
      </header>

      <div className="row g-3 mb-4">
        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Select User</h5>
              <div className="mb-3">
                <label className="form-label">Active User</label>
                <select className="form-select" value={selectedUser} onChange={e => setSelectedUser(e.target.value)}>
                  <option value="">-- Select user --</option>
                  {users.map(u => <option key={u.userId} value={u.userId}>{u.userId} - {u.name}</option>)}
                </select>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-6">
          <div className="card">
            <div className="card-body">
              <h5 className="card-title">Create New User</h5>
              {userError && <div className="alert alert-danger">{userError}</div>}
              {userMessage && <div className="alert alert-success">{userMessage}</div>}
              <form onSubmit={handleCreateUser}>
                <div className="row g-2">
                  <div className="col-4">
                    <input className="form-control" name="userId" placeholder="User ID" value={newUser.userId} onChange={handleCreateChangeUser} required />
                  </div>
                  <div className="col-4">
                    <input className="form-control" name="name" placeholder="Name" value={newUser.name} onChange={handleCreateChangeUser} required />
                  </div>
                  <div className="col-4 d-flex">
                    <input className="form-control me-2" name="email" placeholder="Email" value={newUser.email} onChange={handleCreateChangeUser} required />
                    <button type="submit" className="btn btn-outline-primary" disabled={creatingUser}>{creatingUser ? 'Creating...' : 'Create'}</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

      <div className="card mb-4">
        <div className="card-body">
          <h4 className="card-title">Create New Program</h4>
          {formError && <div className="alert alert-danger">{formError}</div>}
          {createMessage && <div className="alert alert-success">{createMessage}</div>}
          <form onSubmit={handleCreateProgram}>
            <div className="row g-3">
              <div className="col-md-4">
                <label className="form-label">Program ID</label>
                <input className="form-control" name="programId" value={newProgram.programId} onChange={handleCreateChange} required />
              </div>
              <div className="col-md-4">
                <label className="form-label">Name</label>
                <input className="form-control" name="name" value={newProgram.name} onChange={handleCreateChange} required />
              </div>
              <div className="col-md-4">
                <label className="form-label">Category</label>
                <input className="form-control" name="category" value={newProgram.category} onChange={handleCreateChange} required />
              </div>
              <div className="col-md-4">
                <label className="form-label">Level</label>
                <select className="form-select" name="level" value={newProgram.level} onChange={handleCreateChange}>
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>
              <div className="col-md-4">
                <label className="form-label">Price</label>
                <input className="form-control" name="price" type="number" min="0" value={newProgram.price} onChange={handleCreateChange} required />
              </div>
              <div className="col-md-4 d-flex align-items-end">
                <button type="submit" className="btn btn-success w-100" disabled={creating}>{creating ? 'Creating...' : 'Create Program'}</button>
              </div>
            </div>
          </form>
        </div>
      </div>

      {message && <div className={`alert ${message.type === 'success' ? 'alert-success' : 'alert-danger'}`}>{message.text}</div>}

      <div className="card-grid mb-4">
        {programs.map(p => <ProgramCard key={p.programId} program={p} onEnroll={handleEnroll} enrolling={enrollingId===p.programId} />)}
      </div>

      <h4>Enrolled Programs</h4>
      {enrolledPrograms.length === 0 && <p>No enrolled programs yet.</p>}
      <ul className="list-group">
        {enrolledPrograms.map(id => <li key={id} className="list-group-item">{id}</li>)}
      </ul>
    </div>
  );
}
