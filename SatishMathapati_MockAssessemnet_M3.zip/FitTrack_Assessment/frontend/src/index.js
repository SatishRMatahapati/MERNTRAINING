import React from 'react';
import { createRoot } from 'react-dom/client';
import ProgramList from './components/ProgramList';
import './styles.css';

createRoot(document.getElementById('root')).render(<ProgramList />);
