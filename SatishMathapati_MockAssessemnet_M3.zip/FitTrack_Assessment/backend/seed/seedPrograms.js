const mongoose = require('mongoose');
const Program = require('../models/Program');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/fittrack';
const samplePrograms = [
  { programId: "FTP001", name: "Beginner Full Body Workout", category: "Strength Training", level: "Beginner", price:1999 },
  { programId: "FTP002", name: "Weight Loss Intensive", category: "Cardio", level: "Intermediate", price:2499 },
  { programId: "FTP003", name: "HIIT High Performance", category: "Cardio", level: "Advanced", price:2999 },
  { programId: "FTP004", name: "Yoga Mindfulness Program", category: "Yoga", level: "Beginner", price:1499 },
  { programId: "FTP005", name: "Lean Muscle Builder", category: "Strength Training", level: "Intermediate", price:2799 }
];

async function seed() {
  try {
    await mongoose.connect(MONGO_URI);
    console.log('Connected to MongoDB for seeding');
    await Program.deleteMany({});
    await Program.insertMany(samplePrograms);
    console.log('Seeded programs');
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

seed();
