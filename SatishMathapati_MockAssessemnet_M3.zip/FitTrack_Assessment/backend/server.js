require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const morgan = require('morgan');
const cors = require('cors');
const bodyParser = require('body-parser');

const programsRouter = require('./routes/programs');
const enrollRouter = require('./routes/enroll');
const usersRouter = require('./routes/users');
const errorHandler = require('./middleware/errorHandler');

const app = express();
const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/fittrack';

app.use(cors());
app.use(morgan('dev'));
app.use(bodyParser.json());

app.use('/api/programs', programsRouter);
app.use('/api/enroll', enrollRouter);
app.use('/api/users', usersRouter);

// health
app.get('/', (req, res) => res.json({ success: true, message: 'FitTrack API' }));

// Global error handler (must be last)
app.use(errorHandler);

async function start() {
  try {
    await mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB');
    app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
  } catch (err) {
    console.error('Failed to start server', err);
    process.exit(1);
  }
}

if (require.main === module) {
  start();
}

// for testing
module.exports = app;
