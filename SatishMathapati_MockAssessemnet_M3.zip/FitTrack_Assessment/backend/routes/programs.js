const express = require('express');
const Joi = require('joi');
const Program = require('../models/Program');
const router = express.Router();

const programSchema = Joi.object({
  programId: Joi.string().required(),
  name: Joi.string().required(),
  category: Joi.string().required(),
  level: Joi.string().valid('Beginner','Intermediate','Advanced').required(),
  price: Joi.number().min(0).required()
});

// POST /api/programs - add program
router.post('/', async (req, res, next) => {
  try {
    const { error, value } = programSchema.validate(req.body);
    if (error) {
      const err = new Error(error.details[0].message);
      err.status = 400;
      throw err;
    }
    const exists = await Program.findOne({ programId: value.programId });
    if (exists) {
      const err = new Error('Program with provided programId already exists');
      err.status = 409;
      throw err;
    }
    const program = new Program(value);
    const saved = await program.save();
    res.status(201).json({ success: true, message: 'Program created', data: saved });
  } catch (err) {
    next(err);
  }
});

// GET /api/programs - fetch all
router.get('/', async (req, res, next) => {
  try {
    const programs = await Program.find().sort({ createdAt: -1 });
    res.json({ success: true, message: 'Programs fetched', data: programs });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
