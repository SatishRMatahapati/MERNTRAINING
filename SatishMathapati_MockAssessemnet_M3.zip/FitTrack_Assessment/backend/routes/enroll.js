const express = require('express');
const Joi = require('joi');
const Enrollment = require('../models/Enrollment');
const Program = require('../models/Program');
const router = express.Router();

const enrollSchema = Joi.object({
  userId: Joi.string().required(),
  programId: Joi.string().required()
});

// POST /api/enroll
router.post('/', async (req, res, next) => {
  try {
    const { error, value } = enrollSchema.validate(req.body);
    if (error) {
      const err = new Error(error.details[0].message);
      err.status = 400;
      throw err;
    }
    // Ensure program exists
    const program = await Program.findOne({ programId: value.programId });
    if (!program) {
      const err = new Error('Program not found');
      err.status = 404;
      throw err;
    }
    // Prevent duplicate enrollment
    const exists = await Enrollment.findOne({ userId: value.userId, programId: value.programId });
    if (exists) {
      const err = new Error('User already enrolled in this program');
      err.status = 400;
      throw err;
    }
    const enrollment = new Enrollment(value);
    const saved = await enrollment.save();
    res.status(201).json({ success: true, message: 'Enrolled successfully', data: saved });
  } catch (err) {
    // If duplicate key error from index
    if (err.code === 11000) {
      err = new Error('Duplicate enrollment');
      err.status = 400;
    }
    next(err);
  }
});

// GET /api/enroll?userId=... - fetch enrollments for a user (returns programIds and program details)
router.get('/', async (req, res, next) => {
  try {
    const { userId } = req.query;
    if (!userId) {
      const err = new Error('Missing userId query parameter');
      err.status = 400;
      throw err;
    }
    const enrollments = await Enrollment.find({ userId }).lean();
    const programIds = enrollments.map(e => e.programId);
    const programs = await Program.find({ programId: { $in: programIds } });
    res.json({ success: true, message: 'Enrollments fetched', data: programs });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
