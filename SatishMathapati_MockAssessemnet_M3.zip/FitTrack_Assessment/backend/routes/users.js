const express = require('express');
const Joi = require('joi');
const User = require('../models/User');
const router = express.Router();

const userSchema = Joi.object({
  userId: Joi.string().required(),
  name: Joi.string().required(),
  email: Joi.string().email().required()
});

// POST /api/users - create user
router.post('/', async (req, res, next) => {
  try {
    const { error, value } = userSchema.validate(req.body);
    if (error) {
      const err = new Error(error.details[0].message);
      err.status = 400;
      throw err;
    }
    const exists = await User.findOne({ $or: [{ userId: value.userId }, { email: value.email }] });
    if (exists) {
      const err = new Error('User with provided id or email already exists');
      err.status = 409;
      throw err;
    }
    const user = new User(value);
    const saved = await user.save();
    res.status(201).json({ success: true, message: 'User created', data: saved });
  } catch (err) {
    next(err);
  }
});

// GET /api/users - list users
router.get('/', async (req, res, next) => {
  try {
    const users = await User.find().sort({ createdAt: -1 });
    res.json({ success: true, message: 'Users fetched', data: users });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
