const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');
const request = require('supertest');
const app = require('../server');
const Program = require('../models/Program');
const Enrollment = require('../models/Enrollment');
const chai = require('chai');
const expect = chai.expect;

let mongoServer;

describe('Enrollment API', function() {
  before(async function() {
    mongoServer = await MongoMemoryServer.create();
    const uri = mongoServer.getUri();
    await mongoose.connect(uri);
    // seed a program
    await Program.create({ programId: 'FTPTEST', name: 'Test Program', category: 'Test', level: 'Beginner', price: 100 });
  });

  after(async function() {
    await mongoose.disconnect();
    await mongoServer.stop();
  });

  beforeEach(async function() {
    await Enrollment.deleteMany({});
  });

  it('should enroll successfully (201)', async function() {
    const res = await request(app)
      .post('/api/enroll')
      .send({ userId: 'USR101', programId: 'FTPTEST' });
    expect(res.status).to.equal(201);
    expect(res.body.success).to.be.true;
  });

  it('should prevent duplicate enrollment (400)', async function() {
    // first enroll
    await request(app).post('/api/enroll').send({ userId: 'USR101', programId: 'FTPTEST' });
    // duplicate enroll
    const res = await request(app).post('/api/enroll').send({ userId: 'USR101', programId: 'FTPTEST' });
    expect(res.status).to.equal(400);
    expect(res.body.success).to.be.false;
  });
});
