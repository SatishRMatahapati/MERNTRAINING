import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

function BookDetails() {
  const { id } = useParams();
  const [book, setBook] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:4000/books/${id}`)
      .then(res => setBook(res.data));
  }, [id]);

  if (!book) return <p>Loading book details...</p>;

  return (
    <div className="page fade">
      <h2>{book.title}</h2>
      <p><b>Author:</b> {book.author}</p>
      <p><b>Description:</b> {book.description}</p>
      <p><b>Price:</b> ₹{book.price}</p>
    </div>
  );
}

export default BookDetails;
