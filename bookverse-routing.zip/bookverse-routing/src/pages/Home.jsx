import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import withLoading from "../components/LoadingHOC";

function Home({ loading, setLoading }) {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    setLoading(true);
    axios.get("http://localhost:4000/books")
      .then(res => {
        setBooks(res.data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="page fade">
      <h1>BookVerse Library</h1>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <ul>
          {books.map(book => (
            <li key={book.id}>
              <Link to={`/book/${book.id}`}>{book.title}</Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export default withLoading(Home);

