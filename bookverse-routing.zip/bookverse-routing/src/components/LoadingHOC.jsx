import { useState } from "react";

const withLoading = (WrappedComponent) => {
  return (props) => {
    const [loading, setLoading] = useState(false);
    return <WrappedComponent {...props} loading={loading} setLoading={setLoading} />;
  };
};

export default withLoading;
