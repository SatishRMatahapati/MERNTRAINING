const express = require("express");
const { body, validationResult } = require("express-validator");

const router = express.Router();

let courses = [
  {
    id: 1,
    name: "Java",
    duration: "3 Months"
  }
];

// GET All Courses
router.get("/", (req, res) => {
  res.json(courses);
});

// POST Course
router.post(
  "/",
  [
    body("name").notEmpty().withMessage("Course name is required"),
    body("duration").notEmpty().withMessage("Duration is required")
  ],
  (req, res, next) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: errors.array()[0].msg
      });
    }

    const newCourse = {
      id: courses.length + 1,
      name: req.body.name,
      duration: req.body.duration
    };

    courses.push(newCourse);

    res.status(201).json(newCourse);
  }
);

// PUT Course
router.put("/:id", (req, res) => {
  const id = parseInt(req.params.id);

  const course = courses.find(c => c.id === id);

  if (!course) {
    return res.status(404).json({
      error: "Course not found"
    });
  }

  course.name = req.body.name || course.name;
  course.duration = req.body.duration || course.duration;

  res.json(course);
});

// DELETE Course
router.delete("/:id", (req, res) => {
  const id = parseInt(req.params.id);

  courses = courses.filter(c => c.id !== id);

  res.json({
    message: "Course deleted successfully"
  });
});

module.exports = router;