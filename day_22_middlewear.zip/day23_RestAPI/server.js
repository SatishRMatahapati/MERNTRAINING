const express = require("express");
const rateLimit = require("express-rate-limit");

const coursesRouter = require("./routes/courses");
const errorHandler = require("./middleware/errorHandler");

const app = express();

app.use(express.json());

// Challenge 3 - Rate Limiting
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 5,
  message: {
    error: "Too many requests"
  }
});

app.use(limiter);

// API Versioning
app.use("/api/v1/courses", coursesRouter);

// Error Handler
app.use(errorHandler);

const PORT = 4000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});