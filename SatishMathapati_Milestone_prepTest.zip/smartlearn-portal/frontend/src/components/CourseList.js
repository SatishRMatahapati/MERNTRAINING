import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function CourseList() {
  const [courses, setCourses] = useState([]);
  const [enrolled, setEnrolled] = useState([]);  // Stores enrolled course IDs
  const [loading, setLoading] = useState(true);
  const userId = "user123";

  // Fetch courses and current user enrollments on load
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [coursesRes, enrollRes] = await Promise.all([
          axios.get('http://localhost:5000/api/courses'),
          axios.get(`http://localhost:5000/api/enroll?userId=${userId}`)
        ]);

        const allCourses = coursesRes.data.data || [];
        setCourses(allCourses);

        const enrolledCourseIds = (enrollRes.data || []).map(entry => entry.courseId);
        setEnrolled(enrolledCourseIds);
      } catch (error) {
        toast.error("Failed to load courses or enrollments");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Enroll function
  const enroll = (courseId) => {
    axios.post('http://localhost:5000/api/enroll', { userId, courseId })
      .then(() => {
        setEnrolled([...enrolled, courseId]);  // Add to enrolled list
        toast.success(`Enrolled in ${courseId} Successfully!`, {
          position: "top-center",
          theme: "colored",
          autoClose: 3000
        });
      })
      .catch(err => {
        toast.error(err.response?.data?.message || "Already Enrolled!");
      });
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '120px', color: 'white', fontSize: '28px' }}>
        Loading Amazing Courses...
      </div>
    );
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: '40px 20px',
      fontFamily: "'Segoe UI', sans-serif"
    }}>
      <ToastContainer />

      <h1 style={{
        textAlign: 'center',
        color: 'white',
        fontSize: '48px',
        marginBottom: '10px',
        textShadow: '0 4px 15px rgba(0,0,0,0.4)'
      }}>
        SmartLearn Course Portal
      </h1>
      <p style={{ textAlign: 'center', color: '#dfe6ff', fontSize: '22px' }}>
        Unlock Your Future — Enroll Today!
      </p>

      {/* Course Cards */}
      <div style={{
        maxWidth: '1300px',
        margin: '40px auto',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
        gap: '35px'
      }}>
        {courses.map(course => {
          const isEnrolled = enrolled.includes(course.courseId);
          return (
            <div key={course.courseId} style={{
              background: 'white',
              borderRadius: '24px',
              overflow: 'hidden',
              boxShadow: '0 20px 40px rgba(0,0,0,0.25)',
              transform: isEnrolled ? 'translateY(10px)' : 'translateY(0)',
              transition: 'all 0.4s ease',
              opacity: isEnrolled ? 0.9 : 1
            }}>
              {/* Top Banner */}
              <div style={{
                height: '160px',
                background: isEnrolled 
                  ? 'linear-gradient(45deg, #2ecc71, #27ae60)' 
                  : 'linear-gradient(45deg, #9b59b6, #8e44ad)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontSize: '70px',
                fontWeight: 'bold'
              }}>
                {isEnrolled ? '✓' : course.title[0]}
              </div>

              <div style={{ padding: '28px' }}>
                <h3 style={{ fontSize: '26px', margin: '0 0 12px', color: '#2c3e50' }}>
                  {course.title}
                </h3>
                <p style={{ color: '#7f8c8d', fontSize: '17px', margin: '8px 0' }}>
                  Category: <strong style={{ color: '#3498db' }}>{course.category}</strong>
                </p>
                <p style={{ fontSize: '28px', fontWeight: 'bold', color: '#27ae60', margin: '20px 0' }}>
                  ₹{course.price}
                </p>

                <button
                  onClick={() => enroll(course.courseId)}
                  disabled={isEnrolled}
                  style={{
                    width: '100%',
                    padding: '16px',
                    fontSize: '20px',
                    fontWeight: 'bold',
                    border: 'none',
                    borderRadius: '50px',
                    cursor: isEnrolled ? 'not-allowed' : 'pointer',
                    background: isEnrolled 
                      ? '#95a5a6' 
                      : 'linear-gradient(45deg, #e74c3c, #c0392b)',
                    color: 'white',
                    transition: '0.3s'
                  }}
                >
                  {isEnrolled ? 'Already Enrolled' : 'Enroll Now'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* My Enrollments Section */}
      <div style={{
        maxWidth: '1000px',
        margin: '80px auto 40px',
        background: 'rgba(255,255,255,0.18)',
        padding: '40px',
        borderRadius: '30px',
        backdropFilter: 'blur(12px)',
        border: '1px solid rgba(255,255,255,0.2)'
      }}>
        <h2 style={{ color: 'white', textAlign: 'center', fontSize: '36px', marginBottom: '20px' }}>
          My Enrollments ({enrolled.length})
        </h2>

        {enrolled.length === 0 ? (
          <p style={{ textAlign: 'center', color: '#dfe6ff', fontSize: '20px' }}>
            No courses enrolled yet. Pick your first course above!
          </p>
        ) : (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: '20px'
          }}>
            {courses
              .filter(course => enrolled.includes(course.courseId))
              .map(course => (
                <div key={course.courseId} style={{
                  background: 'white',
                  borderRadius: '24px',
                  padding: '24px',
                  boxShadow: '0 20px 40px rgba(0,0,0,0.15)'
                }}>
                  <h3 style={{ fontSize: '24px', margin: '0 0 10px', color: '#2c3e50' }}>
                    {course.title}
                  </h3>
                  <p style={{ color: '#7f8c8d', fontSize: '16px', margin: '0 0 8px' }}>
                    Category: <strong style={{ color: '#3498db' }}>{course.category}</strong>
                  </p>
                  <p style={{ fontSize: '20px', fontWeight: 'bold', color: '#27ae60', margin: '0' }}>
                    ₹{course.price}
                  </p>
                </div>
              ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default CourseList;