require('dotenv').config();
const mongoose = require('mongoose');
const Course = require('./models/Course');

const sampleCourses = [
  {
    courseId: 'C001',
    title: 'React Basics',
    category: 'Web Development',
    price: 49.99
  },
  {
    courseId: 'C002',
    title: 'Node.js Fundamentals',
    category: 'Backend Development',
    price: 59.99
  },
  {
    courseId: 'C003',
    title: 'Data Structures',
    category: 'Computer Science',
    price: 39.99
  }
];

async function seedCourses() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for seeding courses');

    for (const course of sampleCourses) {
      await Course.updateOne(
        { courseId: course.courseId },
        { $setOnInsert: course },
        { upsert: true }
      );
    }

    const allCourses = await Course.find();
    console.log(`Seed completed. ${allCourses.length} course(s) now in the database.`);
    allCourses.forEach((course) => console.log(`${course.courseId}: ${course.title}`));
  } catch (err) {
    console.error('Seeding failed:', err);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
  }
}

seedCourses();
