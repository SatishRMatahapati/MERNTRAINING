const errorHandler = (err, req, res, next) => {
  if (err.code === 11000) {
    return res.status(400).json({ success: false, message: "Already enrolled in this course" });
  }
  if (err.name === 'ValidationError') {
    const messages = Object.values(err.errors).map(e => e.message);
    return res.status(400).json({ success: false, message: messages.join(', ') });
  }
  res.status(500).json({ success: false, message: "Server Error" });
};

module.exports = errorHandler;