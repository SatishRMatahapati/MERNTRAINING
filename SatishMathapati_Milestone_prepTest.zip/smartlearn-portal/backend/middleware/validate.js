const Joi = require('joi');

const courseValidation = Joi.object({
  courseId: Joi.string().required(),
  title: Joi.string().required(),
  category: Joi.string().required(),
  price: Joi.number().min(0).required()
});

const enrollValidation = Joi.object({
  userId: Joi.string().required(),
  courseId: Joi.string().required()
});

const validateCourse = (req, res, next) => {
  const { error } = courseValidation.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });
  next();
};

const validateEnroll = (req, res, next) => {
  const { error } = enrollValidation.validate(req.body);
  if (error) return res.status(400).json({ success: false, message: error.details[0].message });
  next();
};

module.exports = { validateCourse, validateEnroll };