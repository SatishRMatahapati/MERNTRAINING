const chai = require('chai');
const chaiHttp = require('chai-http');
const server = require('../server');
const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');

chai.use(chaiHttp);
const expect = chai.expect;

describe('Enrollment API', () => {
  before(async () => {
    await Course.deleteMany({});
    await Enrollment.deleteMany({});
    await Course.create({ courseId: "TEST101", title: "Test", category: "Test", price: 100 });
  });

  it('should enroll successfully', (done) => {
    chai.request(server)
      .post('/api/enroll')
      .send({ userId: "user123", courseId: "TEST101" })
      .end((err, res) => {
        expect(res.status).to.equal(201);
        done();
      });
  });

  it('should block duplicate enrollment', (done) => {
    chai.request(server)
      .post('/api/enroll')
      .send({ userId: "user123", courseId: "TEST101" })
      .end((err, res) => {
        expect(res.status).to.equal(400);
        done();
      });
  });
});