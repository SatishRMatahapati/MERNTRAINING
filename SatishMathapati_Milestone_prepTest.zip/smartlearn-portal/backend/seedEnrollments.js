require('dotenv').config();
const mongoose = require('mongoose');
const Enrollment = require('./models/Enrollment');
const Course = require('./models/Course');

const sampleEnrollments = [
  { userId: 'user123', courseId: 'C001' },
  { userId: 'user456', courseId: 'C002' },
  { userId: 'user789', courseId: 'C003' }
];

async function seedEnrollments() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('Connected to MongoDB for seeding enrollments');

    for (const enrollment of sampleEnrollments) {
      const course = await Course.findOne({ courseId: enrollment.courseId });
      if (!course) {
        console.warn(`Skipping enrollment for missing course ${enrollment.courseId}`);
        continue;
      }
      await Enrollment.updateOne(
        { userId: enrollment.userId, courseId: enrollment.courseId },
        { $setOnInsert: enrollment },
        { upsert: true }
      );
    }

    const allEnrollments = await Enrollment.find();
    console.log(`Enroll seed complete. ${allEnrollments.length} enrollment(s) now in the database.`);
    allEnrollments.forEach((entry) => console.log(`${entry.userId} enrolled in ${entry.courseId}`));
  } catch (err) {
    console.error('Seeding enrollments failed:', err);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
  }
}

seedEnrollments();
