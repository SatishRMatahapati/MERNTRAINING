const express = require('express');
const router = express.Router();
const Enrollment = require('../models/Enrollment');
const Course = require('../models/Course');
const { validateEnroll } = require('../middleware/validate');

// Test GET route
router.get('/', async (req, res) => {
  try {
    const { userId } = req.query;
    const query = userId ? { userId } : {};
    const enrollments = await Enrollment.find(query);
    res.status(200).json(enrollments);
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST route
router.post('/', validateEnroll, async (req, res) => {
  const { userId, courseId } = req.body;

  const courseExists = await Course.findOne({ courseId });
  if (!courseExists) {
    return res.status(404).json({ success: false, message: "Course not found" });
  }

  try {
    const enrollment = new Enrollment({ userId, courseId });
    await enrollment.save();
    res.status(201).json({ success: true, message: "Enrolled successfully!" });
  } catch (err) {
    res.status(400).json({ success: false, message: "Already enrolled" });
  }
});

module.exports = router;
