
/*
==================================================
    MODULE PATTERN
==================================================

Why are we using Module Pattern?

1. Avoids global variables
2. Keeps code organized
3. Improves maintainability
4. Makes application scalable
5. Protects private data/functions

Everything is wrapped inside App module.
*/

const App = (() => {

    /*
    ==================================================
        API URLs
    ==================================================

    These URLs are used to fetch data from server.
    */

    const POSTS_API = "https://jsonplaceholder.typicode.com/posts";

    const TODOS_API = "https://jsonplaceholder.typicode.com/todos";


    /*
    ==================================================
        DOM ELEMENTS
    ==================================================

    Accessing HTML elements using their IDs
    so we can insert data dynamically.
    */

    const postsContainer =
        document.getElementById("posts-container");

    const todosContainer =
        document.getElementById("todos-container");

    const errorMessage =
        document.getElementById("error-message");


    /*
    ==================================================
        SHOW ERROR FUNCTION
    ==================================================

    Why?

    If API fails or internet issue happens,
    we show error message to user.
    */

    const showError = (message) => {

        /* Make error box visible */
        errorMessage.style.display = "block";

        /* Show error text */
        errorMessage.innerText = message;
    };


    /*
    ==================================================
        FETCH POSTS FUNCTION
    ==================================================

    Why async/await?

    API requests take time.
    async/await helps handle asynchronous operations cleanly.
    */

    const fetchPosts = async () => {

        try {

            /*
            Calling Posts API
            fetch() returns a Promise
            */
            const response = await fetch(POSTS_API);


            /*
            ==================================================
                ERROR HANDLING
            ==================================================

            If response is not successful,
            throw custom error.
            */

            if (!response.ok) {

                throw new Error("Failed to fetch posts");
            }


            /*
            Convert JSON response into JavaScript objects
            */
            const posts = await response.json();


            /*
            Send only first 10 posts to display function
            slice(0,10) limits data
            */
            displayPosts(posts.slice(0, 10));

        }
        catch (error) {

            /*
            If any error occurs,
            display it on screen
            */

            showError(error.message);
        }
    };


    /*
    ==================================================
        DISPLAY POSTS FUNCTION
    ==================================================

    Why?

    Dynamically create HTML elements
    and display fetched data.
    */

    const displayPosts = (posts) => {

        /*
        Loop through all posts
        */
        posts.forEach(post => {

            /*
            Create new div element
            */
            const postCard =
                document.createElement("div");

            /*
            Add card class for styling
            */
            postCard.classList.add("card");


            /*
            Insert dynamic HTML data
            */
            postCard.innerHTML = `
                <h3>${post.title}</h3>
                <p>${post.body}</p>
            `;


            /*
            Add post card to webpage
            */
            postsContainer.appendChild(postCard);
        });
    };


    /*
    ==================================================
        FETCH TODOS FUNCTION
    ==================================================

    Fetching todo data from server.
    */

    const fetchTodos = async () => {

        try {

            /*
            API call
            */
            const response = await fetch(TODOS_API);


            /*
            Check if request successful
            */
            if (!response.ok) {

                throw new Error("Failed to fetch todos");
            }


            /*
            Convert response into JSON
            */
            const todos = await response.json();


            /*
            Display only first 10 todos
            */
            displayTodos(todos.slice(0, 10));

        }
        catch (error) {

            /*
            Show error if request fails
            */
            showError(error.message);
        }
    };


    /*
    ==================================================
        DISPLAY TODOS FUNCTION
    ==================================================

    Dynamically creates todo cards
    and shows completion status.
    */

    const displayTodos = (todos) => {

        /*
        Loop through each todo
        */
        todos.forEach(todo => {

            /*
            Create div
            */
            const todoCard =
                document.createElement("div");

            /*
            Add styling class
            */
            todoCard.classList.add("card");


            /*
            Ternary Operator Used

            If completed = true
            show "Completed"

            else
            show "Pending"
            */

            todoCard.innerHTML = `
                <p>
                    ${todo.title}
                    -
                    <span class="${
                        todo.completed
                        ? 'completed'
                        : 'pending'
                    }">

                        ${
                            todo.completed
                            ? 'Completed'
                            : 'Pending'
                        }

                    </span>
                </p>
            `;


            /*
            Add todo card to webpage
            */
            todosContainer.appendChild(todoCard);
        });
    };


    /*
    ==================================================
        INITIALIZE APPLICATION
    ==================================================

    Why?

    Starts application execution.
    Calls all required functions.
    */

    const init = () => {

        fetchPosts();

        fetchTodos();
    };


    /*
    ==================================================
        PUBLIC METHODS
    ==================================================

    Returning init method so it can be accessed outside.
    */

    return {

        init
    };

})();


/*
==================================================
    START APPLICATION
==================================================

Calling init() to run application.
*/

App.init();