function login() {

    let username =
    document.getElementById("username").value;

    let password =
    document.getElementById("password").value;


    if(username === "admin" && password === "1234") {

        window.location.href = "profile.html";

    }
    else {

        document.getElementById("message").innerHTML =
        "Invalid Username or Password";

    }

}



const activities = [

    {
        id: 1,
        activity: "Solved Algebra Problems",
        subject: "Maths"
    },

    {
        id: 2,
        activity: "Completed Science Experiment",
        subject: "Science"
    },

    {
        id: 3,
        activity: "Essay Writing",
        subject: "English"
    },

    {
        id: 4,
        activity: "Geometry Practice",
        subject: "Maths"
    },

    {
        id: 5,
        activity: "Lab Record Submission",
        subject: "Science"
    }

];



function showActivities(subject) {

    let result = "";

    let filteredActivities =
    activities.filter(function(item){

        return item.subject === subject;

    });


    filteredActivities.forEach(function(item){

        result += `

            <div class="activity-card">

                <h5>${item.subject}</h5>

                <p>${item.activity}</p>

            </div>

        `;

    });


    document.getElementById("activityBox").innerHTML =
    result;

    
    function registerUser() {

    alert("Registration Successful");

    window.location.href = "login.html";

}


}